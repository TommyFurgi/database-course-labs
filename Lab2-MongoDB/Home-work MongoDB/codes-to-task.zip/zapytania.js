// Polecenie wyświetlające listę wycieczek, na które zapisana jest dana osoba:

// Wariant 1:
db.tours.aggregate([
  { 
    $unwind: "$reservations" 
  },
  {
    $match: {
      "reservations.user_id": "101"
    }
  },
  {
    $lookup: {
      from: "companies",
      localField: "company_id",
      foreignField: "company_id",
      as: "company"
    }
  },
  {
    $unwind: "$company"
  },
  {
    $lookup: {
      from: "persons",
      localField: "reservations.user_id",
      foreignField: "user_id",
      as: "user"
    }
  },
  {
    $unwind: "$user"
  },
  {
    $project: {
      "_id": 0,
      "user_name": "$user.name",
      "tour_id": 1,
      "tour_name": 1,
      "date": 1,
      "price": 1,
      "company_name": "$company.company_name",
      "reservation_date": "$reservations.date"
    }
  }
])

// Wariant 2:
db.reservations.aggregate([
  {
    $match: {
      user_id: "101" 
    }
  },
  {
    $lookup: {
      from: "tours",
      localField: "tour_id",
      foreignField: "tour_id",
      as: "tour_info"
    }
  },
  {
    $unwind: "$tour_info" 
  },
  {
    $lookup: {
      from: "persons",
      localField: "user_id",
      foreignField: "user_id",
      as: "user_info"
    }
  },
  {
    $lookup: {
      from: "companies",
      localField: "tour_info.company_id",
      foreignField: "company_id",
      as: "company_info"
    }
  },
  {
    $unwind: "$user_info" 
  },
  {
    $unwind: "$company_info" 
  },
  {
    $project: {
      _id: 0,
      tour_id: "$tour_info.tour_id",
      tour_name: "$tour_info.tour_name",
      date: "$tour_info.date",
      price: "$tour_info.price",
      user_name: "$user_info.name",
      company_name: "$company_info.company_name",
      reservation_date: "$date"
    }
  }
])

// Wariant 3:
db.companies.aggregate([
  {
    $unwind: "$tours"
  },
  {
    $unwind: "$tours.reservations" 
  },
  {
    $match: {
      "tours.reservations.user_id": "101" 
    }
  },
  {
    $lookup: {
      from: "persons",
      localField: "tours.reservations.user_id",
      foreignField: "user_id",
      as: "user"
    }
  },
  {
    $project: {
      _id: 0,
      tour_name: "$tours.tour_name",
      company_name: "$company_name",
      date: "$tours.date",
      price: "$tours.price",
      user_name: { $arrayElemAt: ["$user.name", 0] }, 
      reservation_date: "$tours.reservations.date" 
    }
  }
]);


// Polecenie wyświetlające wycieczki, które posiadają co najmniej jedną ocenę równą 5. Wynik sortuje alfabetycznie po nazwie wycieczek:

// Wariant 1:
db.tours.aggregate([
  {
    $match: {
      "ratings.rating": { $gte: 5 } 
    }
  },
  {
    $project: {
      "_id": 0,
      "tour_name": 1,
      "num_of_5_ratings": {
        $size: { 
          $filter: {
            input: "$ratings",
            as: "rating",
            cond: { $eq: ["$$rating.rating", 5] }
          }
        }
      }
    }
  }
])

// Wariant 2:
db.tours.aggregate([
  {
    $match: {
      "ratings.rating": 5 
    }
  },
  {
    $project: {
      _id: 0,
      tour_name: 1,
      num_ratings_5: {
        $size: {
          $filter: {
            input: "$ratings",
            as: "rating",
            cond: { $eq: ["$$rating.rating", 5] }
          }
        }
      }
    }
  },
  {
    $sort: {
      tour_name: 1 
    }
  }
])

// Wariant 3:
db.companies.aggregate([
  {
    $unwind: "$tours" 
  },
  {
    $unwind: {
      path: "$tours.ratings",
      preserveNullAndEmptyArrays: true
    } // Rozwijamy tablicę ocen w ramach wycieczki
  },
  {
    $match: {
      "tours.ratings.rating": { $eq: 5 } 
    }
  },
  {
    $group: {
      _id: "$tours.tour_name",
      count: { $sum: 1 } 
    }
  },
  {
    $sort: {
      tour_name: 1 
    }
  },
  {
    $project: {
      _id: 0,
      tour_name: "$_id",
      count_of_5_ratings: "$count"
    }
  }
]);


// Polecenie wyświetlające nazwę wycieczek wraz z liczbą rezerwacji:

// Wariant 1:
db.tours.find(
  {}, 
  { 
    _id: 0, 
    tour_name: 1, 
    reservations_count: { $size: "$reservations" } 
  }
)

// Wariant 2:
db.tours.aggregate([
  {
    $lookup: {
      from: "reservations",
      localField: "tour_id",
      foreignField: "tour_id",
      as: "reservations"
    }
  },
  {
    $project: {
      _id: 0,
      tour_name: 1,
      num_reservations: { $size: "$reservations" }
    }
  }
])

// Wariant 3:
db.companies.aggregate([
  {
    $unwind: "$tours" 
  },
  {
    $project: {
      "_id": 0,
      "tour_name": "$tours.tour_name",
      "reservations_count": { $size: "$tours.reservations" }
    }
  }
])


// Dodanie nowej rezerwacji:

// Wariant 1:
db.tours.updateOne(
  { 
    "tour_id": "1"
  },
  {
    $addToSet: {
      "reservations": { "user_id": "103", "date": "2024-05-11" }
    }
  }
);

// Wariant 2:
db.reservations.insertOne({
  "reservation_id": "6",
  "tour_id": "1",
  "user_id": "103", 
  "date": "2024-05-11" 
});

// Wariant 3:
db.companies.updateOne(
  { "company_id": "1" }, // Dopasowujemy firmę pierwszą
  {
    $push: {
      "tours.$[tour].reservations": { "user_id": "103", "date": "2024-05-11" }
    }
  },
  {
    arrayFilters: [{ "tour.tour_name": "Excursion to Grand Canyon" }] 
  }
);


// Dodanie nowej oceny:

// Wariant 1:
db.tours.updateOne(
  { "tour_id": "1" },
  { 
    $push: { 
      "ratings": {
        "user_id": "106",
        "rating": 3
      } 
    } 
  }
);


// Wariant 2:
db.tours.updateOne(
  { "tour_id": "1" },
  { 
    $push: { 
      "ratings": { 
        "user_id": "106",
        "rating": 3 
      } 
    } 
  }
)

// Wariant 3:
db.companies.updateOne(
  { "company_id": "1", "tours.tour_name": "Excursion to Grand Canyon" },
  {
    $push: {
      "tours.$.ratings": { "user_id": "106", "rating": 3 }
    }
  }
);


// Usunięcie rezerwacji na wycieczkę:

// Wariant 1:
db.tours.updateOne(
  { 
    "tour_id": "1", 
    "reservations.user_id": "103" 
  },
  {
    $pull: { 
      "reservations": {
        "user_id": "103"
      }
    }
  }
)

// Wariant 2:
db.reservations.deleteOne({
  user_id: "103",
  tour_id: "1"
})

// Wariant 3:
db.companies.updateOne(
  { 
    "company_id": "1",
    "tours.tour_name": "Excursion to Grand Canyon",
  },
  { 
    $pull: { 
      "tours.$.reservations": { "user_id": "103" } 
    } 
  }
);
